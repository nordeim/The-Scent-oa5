-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: the_scent
-- ------------------------------------------------------
-- Server version	8.0.41-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `the_scent`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `the_scent` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `the_scent`;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL,
  `user_id` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `details` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES (1,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-23 13:56:09'),(2,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-24 12:21:06'),(3,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 12:01:15'),(4,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 12:01:15'),(5,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 12:01:29'),(6,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 12:01:29'),(7,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:22:14'),(8,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:22:14'),(9,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:22:32'),(10,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:22:32'),(11,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:43:20'),(12,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:43:20'),(13,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:44:06'),(14,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 13:44:06'),(15,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-25 15:59:40'),(16,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 01:47:48'),(17,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 06:12:42'),(18,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 11:33:48'),(19,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 11:34:01'),(20,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 21:50:17'),(21,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 21:50:28'),(22,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 23:10:57'),(23,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 23:11:03'),(24,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 23:23:00'),(25,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-26 23:23:14'),(26,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 00:55:45'),(27,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 00:56:02'),(28,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 06:44:11'),(29,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 06:44:22'),(30,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 07:10:06'),(31,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-27 07:10:20'),(32,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 01:08:02'),(33,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 02:07:10'),(34,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":true,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 02:07:21'),(35,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 05:02:05'),(36,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 05:30:27'),(37,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 06:12:38'),(38,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-04-28 06:13:29'),(39,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 10:23:18'),(40,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-04-28 10:24:04'),(41,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-28 11:45:22'),(42,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-04-28 11:46:23'),(43,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 04:29:01'),(44,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 04:30:04'),(45,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 05:07:29'),(46,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 06:47:28'),(47,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 11:36:25'),(48,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-04-29 11:37:23'),(49,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-04-29 11:45:52'),(50,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-01 13:20:35'),(51,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":15,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-02 00:22:51'),(52,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":4,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-02 04:19:48'),(53,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 01:23:32'),(54,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 01:23:41'),(55,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 05:03:18'),(56,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":7,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 05:03:30'),(57,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 05:05:23'),(58,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 08:40:19'),(59,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 08:40:52'),(60,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 09:01:28'),(61,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 09:01:35'),(62,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 09:02:08'),(63,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 11:00:00'),(64,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 12:59:48'),(65,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-03 13:00:00'),(66,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 13:00:46'),(67,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-03 23:57:05'),(68,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-04 02:11:45'),(69,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-04 02:12:20'),(70,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-04 07:26:05'),(71,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-04 08:16:21'),(72,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-04 08:16:50'),(73,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-05 22:08:44'),(74,'profile_address_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"country\":\"US\"}','2025-05-05 22:10:00'),(75,'cart_remove',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"ip\":\"127.0.0.1\"}','2025-05-05 22:12:51'),(76,'cart_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"updates\":{\"1\":\"1\",\"7\":\"1\"},\"ip\":\"127.0.0.1\",\"had_stock_errors\":false,\"db_update_failed\":false}','2025-05-05 22:12:54'),(77,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-05 22:32:57'),(78,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-06 01:44:01'),(79,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":6,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-06 01:45:56'),(80,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 01:46:40'),(81,'profile_address_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"country\":\"US\"}','2025-05-06 01:48:11'),(82,'cart_remove',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":6,\"ip\":\"127.0.0.1\"}','2025-05-06 01:48:43'),(83,'cart_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"updates\":{\"1\":\"1\",\"7\":\"1\"},\"ip\":\"127.0.0.1\",\"had_stock_errors\":false,\"db_update_failed\":false}','2025-05-06 01:48:46'),(84,'cart_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"updates\":{\"1\":\"1\",\"7\":\"2\"},\"ip\":\"127.0.0.1\",\"had_stock_errors\":false,\"db_update_failed\":false}','2025-05-06 01:48:51'),(85,'user_registered',9,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 01:52:58'),(86,'login_success',9,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 01:53:19'),(87,'login_success',9,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 06:33:50'),(88,'cart_add',9,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-06 06:37:13'),(89,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"relaxation\"},\"recommendations_count\":3}','2025-05-06 08:00:26'),(90,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-06 08:00:30'),(91,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"focus\"},\"recommendations_count\":3}','2025-05-06 08:00:34'),(92,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"balance\"},\"recommendations_count\":3}','2025-05-06 08:00:37'),(93,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 08:02:38'),(94,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"relaxation\"},\"recommendations_count\":3}','2025-05-06 08:28:08'),(95,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-06 08:28:11'),(96,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"focus\"},\"recommendations_count\":3}','2025-05-06 08:28:13'),(97,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"balance\"},\"recommendations_count\":3}','2025-05-06 08:28:16'),(98,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-06 08:29:06'),(99,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-06 08:29:16'),(100,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 08:29:49'),(101,'cart_remove',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"ip\":\"127.0.0.1\"}','2025-05-06 08:30:50'),(102,'cart_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"updates\":{\"1\":\"1\",\"7\":\"1\"},\"ip\":\"127.0.0.1\",\"had_stock_errors\":false,\"db_update_failed\":false}','2025-05-06 08:30:51'),(103,'user_registered',10,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 08:32:03'),(104,'login_success',10,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-06 08:32:21'),(105,'profile_address_update',10,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"country\":\"AU\"}','2025-05-06 08:32:55'),(106,'cart_add',10,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-06 08:33:12'),(107,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-08 01:11:07'),(108,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"focus\"},\"recommendations_count\":3}','2025-05-08 01:11:13'),(109,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"balance\"},\"recommendations_count\":3}','2025-05-08 01:11:16'),(110,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"relaxation\"},\"recommendations_count\":3}','2025-05-08 01:11:19'),(111,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-08 01:12:39'),(112,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 01:14:15'),(113,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 01:22:07'),(114,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 01:27:40'),(115,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-08 01:31:47'),(116,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"relaxation\"},\"recommendations_count\":3}','2025-05-08 01:31:51'),(117,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"focus\"},\"recommendations_count\":3}','2025-05-08 01:31:53'),(118,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"balance\"},\"recommendations_count\":3}','2025-05-08 01:31:55'),(119,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 01:33:29'),(120,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 01:50:15'),(121,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 03:07:57'),(122,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"relaxation\"},\"recommendations_count\":3}','2025-05-08 11:20:08'),(123,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"energy\"},\"recommendations_count\":3}','2025-05-08 11:20:10'),(124,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"focus\"},\"recommendations_count\":3}','2025-05-08 11:20:12'),(125,'quiz_completed',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"answers\":{\"mood\":\"balance\"},\"recommendations_count\":3}','2025-05-08 11:20:14'),(126,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-08 11:21:22'),(127,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":2,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-08 11:21:31'),(128,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 11:22:07'),(129,'cart_add',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"product_id\":1,\"quantity\":1,\"ip\":\"127.0.0.1\"}','2025-05-08 12:06:24'),(130,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 12:13:58'),(131,'cart_update',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','{\"updates\":{\"1\":\"1\",\"7\":\"1\",\"2\":\"1\"},\"ip\":\"127.0.0.1\",\"had_stock_errors\":false,\"db_update_failed\":false}','2025-05-08 12:14:12'),(132,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-08 12:29:40'),(133,'login_success',6,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','[]','2025-05-09 02:33:06');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `session_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `cart_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
INSERT INTO `cart_items` VALUES (1,6,NULL,1,1),(2,6,NULL,7,1),(5,9,NULL,2,1),(7,10,NULL,2,1),(8,6,NULL,2,1),(23,1,NULL,1,1);
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Essential Oils','Pure essential oils for aromatherapy and wellness'),(2,'Natural Soaps','Handcrafted natural soaps with therapeutic properties'),(3,'Diffuser Blends','Pre-mixed blends for aromatherapy diffusers'),(4,'Gift Sets','Curated collections of our premium products'),(5,'Essential Oils','Pure essential oils for aromatherapy and wellness'),(6,'Natural Soaps','Handcrafted natural soaps with therapeutic properties'),(7,'Diffuser Blends','Pre-mixed blends for aromatherapy diffusers'),(8,'Gift Sets','Curated collections of our premium products'),(9,'Essential Oils','Pure essential oils for aromatherapy and wellness'),(10,'Natural Soaps','Handcrafted natural soaps with therapeutic properties'),(11,'Diffuser Blends','Pre-mixed blends for aromatherapy diffusers'),(12,'Gift Sets','Curated collections of our premium products'),(13,'Essential Oils','Pure essential oils for aromatherapy and wellness'),(14,'Natural Soaps','Handcrafted natural soaps with therapeutic properties'),(15,'Diffuser Blends','Pre-mixed blends for aromatherapy diffusers'),(16,'Gift Sets','Curated collections of our premium products');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `to_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('sent','failed','pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `mailer_error` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `user_id` int DEFAULT NULL,
  `email_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g., welcome, password_reset, order_confirmation',
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_to_email_status` (`to_email`,`status`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_email_type` (`email_type`),
  CONSTRAINT `fk_email_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
INSERT INTO `email_log` VALUES (1,'asd@zxc.com','Welcome to The Scent!','sent',NULL,NULL,'welcome_email','2025-05-06 01:52:58'),(2,'qaz@wsx.com','Welcome to The Scent!','sent',NULL,NULL,'welcome_email','2025-05-06 08:32:03');
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `quantity_change` int NOT NULL,
  `type` enum('sale','restock','return','adjustment') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` int DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_date` (`product_id`,`created_at`),
  KEY `idx_type` (`type`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletter_subscribers`
--

DROP TABLE IF EXISTS `newsletter_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `newsletter_subscribers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscribed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_subscribers`
--

LOCK TABLES `newsletter_subscribers` WRITE;
/*!40000 ALTER TABLE `newsletter_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `newsletter_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `coupon_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_id` int DEFAULT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `shipping_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `shipping_address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `status` enum('pending_payment','paid','processing','shipped','delivered','cancelled','refunded','disputed','payment_failed','completed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending_payment',
  `payment_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_intent_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `paid_at` datetime DEFAULT NULL,
  `dispute_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disputed_at` datetime DEFAULT NULL,
  `refund_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refunded_at` datetime DEFAULT NULL,
  `tracking_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carrier` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_payment_intent_id` (`payment_intent_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attributes`
--

DROP TABLE IF EXISTS `product_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attributes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `scent_type` enum('floral','woody','citrus','oriental','fresh') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mood_effect` enum('calming','energizing','focusing','balancing') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `intensity_level` enum('light','medium','strong') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_attributes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attributes`
--

LOCK TABLES `product_attributes` WRITE;
/*!40000 ALTER TABLE `product_attributes` DISABLE KEYS */;
INSERT INTO `product_attributes` VALUES (1,1,'floral','calming','medium'),(2,2,'citrus','energizing','strong'),(3,3,'woody','focusing','strong'),(4,4,'floral','balancing','medium'),(5,5,'fresh','energizing','strong'),(6,6,'floral','calming','light'),(7,7,'citrus','energizing','medium'),(8,8,'woody','focusing','medium'),(9,9,'floral','balancing','light'),(10,10,'fresh','energizing','medium'),(11,11,'floral','calming','medium'),(12,12,'citrus','energizing','strong'),(13,13,'woody','focusing','medium'),(14,14,'oriental','calming','strong'),(15,15,'fresh','balancing','medium'),(16,1,'floral','calming','medium'),(17,6,'floral','calming','medium'),(18,11,'floral','calming','strong'),(19,14,'woody','calming','medium'),(20,2,'citrus','energizing','strong'),(21,5,'fresh','energizing','strong'),(22,7,'citrus','energizing','medium'),(23,10,'fresh','energizing','medium'),(24,12,'citrus','energizing','strong'),(25,3,'woody','focusing','medium'),(26,8,'woody','focusing','medium'),(27,13,'fresh','focusing','strong'),(28,4,'floral','balancing','medium'),(29,9,'floral','balancing','light'),(30,15,'oriental','balancing','medium');
/*!40000 ALTER TABLE `product_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `short_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Brief description for listings/previews',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery_images` json DEFAULT NULL COMMENT 'JSON array of additional image paths',
  `price` decimal(10,2) DEFAULT NULL,
  `benefits` json DEFAULT NULL COMMENT 'Product benefits, stored as JSON array of strings',
  `ingredients` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'List of key ingredients',
  `usage_instructions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'How to use the product',
  `category_id` int DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `low_stock_threshold` int DEFAULT '20',
  `reorder_point` int DEFAULT '30',
  `backorder_allowed` tinyint(1) DEFAULT '0' COMMENT '0 = No, 1 = Yes. Allow purchase when stock_quantity <= 0',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `highlight_text` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_quantity` int DEFAULT '0',
  `size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g., 10ml, 100g',
  `scent_profile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Simple text description of scent (Alternative: Use JOIN with product_attributes table)',
  `origin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Country or region of origin',
  `sku` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Stock Keeping Unit',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku_unique` (`sku`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Lavender Serenity Oil','Pure lavender essential oil for relaxation and calm.',NULL,'/images/products/1.jpg',NULL,24.99,NULL,NULL,NULL,1,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13','Best Seller',10,NULL,NULL,NULL,NULL),(2,'Citrus Burst Oil','Energizing blend of orange, lemon, and grapefruit oils.',NULL,'/images/products/2.jpg',NULL,19.99,NULL,NULL,NULL,1,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(3,'Forest Pine Oil','Refreshing pine essential oil for focus and clarity.',NULL,'/images/products/3.jpg',NULL,22.99,NULL,NULL,NULL,1,0,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(4,'Rose Harmony Oil','Premium rose essential oil for emotional balance.',NULL,'/images/products/4.jpg',NULL,29.99,NULL,NULL,NULL,1,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13','New Arrival',10,NULL,NULL,NULL,NULL),(5,'Eucalyptus Fresh Oil','Invigorating eucalyptus oil for energy and vitality.',NULL,'/images/products/5.jpg',NULL,18.99,NULL,NULL,NULL,1,0,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(6,'Lavender Dreams Soap','Calming lavender soap with natural oils.',NULL,'/images/products/6.jpg',NULL,12.99,NULL,NULL,NULL,2,1,'2025-04-13 16:28:11',30,50,0,'2025-04-22 03:33:13','Best Seller',10,NULL,NULL,NULL,NULL),(7,'Citrus Morning Soap','Energizing citrus soap for a fresh start.',NULL,'/images/products/7.jpg',NULL,11.99,NULL,NULL,NULL,2,1,'2025-04-13 16:28:11',30,50,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(8,'Forest Walk Soap','Woodsy soap with pine and cedar notes.',NULL,'/images/products/8.jpg',NULL,12.99,NULL,NULL,NULL,2,0,'2025-04-13 16:28:11',30,50,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(9,'Rose Petal Soap','Delicate rose-scented soap for gentle cleansing.',NULL,'/images/products/9.jpg',NULL,13.99,NULL,NULL,NULL,2,1,'2025-04-13 16:28:11',30,50,0,'2025-04-22 03:33:13','New Arrival',10,NULL,NULL,NULL,NULL),(10,'Mountain Air Soap','Refreshing soap with mint and eucalyptus.',NULL,'/images/products/10.jpg',NULL,11.99,NULL,NULL,NULL,2,0,'2025-04-13 16:28:11',30,50,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(11,'Peaceful Night Blend','Soothing blend for restful sleep.',NULL,'/images/products/11.jpg',NULL,27.99,NULL,NULL,NULL,3,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13','Best Seller',10,NULL,NULL,NULL,NULL),(12,'Morning Energy Blend','Uplifting blend for morning motivation.',NULL,'/images/products/12.jpg',NULL,25.99,NULL,NULL,NULL,3,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(13,'Focus Master Blend','Concentration-enhancing essential oil blend.',NULL,'/images/products/13.jpg',NULL,26.99,NULL,NULL,NULL,3,0,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL),(14,'Stress Relief Blend','Calming blend for stress reduction.',NULL,'/images/products/14.jpg',NULL,28.99,NULL,NULL,NULL,3,1,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13','New Arrival',10,NULL,NULL,NULL,NULL),(15,'Balance & Harmony','Centering blend for emotional balance.',NULL,'/images/products/15.jpg',NULL,29.99,NULL,NULL,NULL,3,0,'2025-04-13 16:28:11',20,30,0,'2025-04-22 03:33:13',NULL,10,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_results`
--

DROP TABLE IF EXISTS `quiz_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `recommendations` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user_timestamp` (`user_id`,`created_at`),
  CONSTRAINT `quiz_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_results`
--

LOCK TABLES `quiz_results` WRITE;
/*!40000 ALTER TABLE `quiz_results` DISABLE KEYS */;
INSERT INTO `quiz_results` VALUES (1,NULL,NULL,'{\"mood\":\"undefined\"}','[1,14,6]','2025-05-05 01:02:29'),(2,NULL,NULL,'{\"mood\":\"undefined\"}','[6,14,1]','2025-05-05 08:06:46'),(3,NULL,NULL,'{\"mood\":\"energy\"}','[7,2,10]','2025-05-06 01:44:01'),(4,NULL,NULL,'{\"mood\":\"relaxation\"}','[6,11,1]','2025-05-06 08:00:26'),(5,NULL,NULL,'{\"mood\":\"energy\"}','[5,12,2]','2025-05-06 08:00:30'),(6,NULL,NULL,'{\"mood\":\"focus\"}','[13,3,8]','2025-05-06 08:00:34'),(7,NULL,NULL,'{\"mood\":\"balance\"}','[15,9,4]','2025-05-06 08:00:37'),(8,NULL,NULL,'{\"mood\":\"relaxation\"}','[11,14,6]','2025-05-06 08:28:08'),(9,NULL,NULL,'{\"mood\":\"energy\"}','[10,12,5]','2025-05-06 08:28:11'),(10,NULL,NULL,'{\"mood\":\"focus\"}','[13,8,3]','2025-05-06 08:28:13'),(11,NULL,NULL,'{\"mood\":\"balance\"}','[15,4,9]','2025-05-06 08:28:16'),(12,NULL,NULL,'{\"mood\":\"energy\"}','[5,10,2]','2025-05-08 01:11:07'),(13,NULL,NULL,'{\"mood\":\"focus\"}','[13,3,8]','2025-05-08 01:11:13'),(14,NULL,NULL,'{\"mood\":\"balance\"}','[4,15,9]','2025-05-08 01:11:16'),(15,NULL,NULL,'{\"mood\":\"relaxation\"}','[14,1,6]','2025-05-08 01:11:19'),(16,NULL,NULL,'{\"mood\":\"energy\"}','[5,7,2]','2025-05-08 01:12:39'),(17,NULL,NULL,'{\"mood\":\"energy\"}','[5,10,12]','2025-05-08 01:31:47'),(18,NULL,NULL,'{\"mood\":\"relaxation\"}','[11,6,14]','2025-05-08 01:31:51'),(19,NULL,NULL,'{\"mood\":\"focus\"}','[13,3,8]','2025-05-08 01:31:53'),(20,NULL,NULL,'{\"mood\":\"balance\"}','[9,15,4]','2025-05-08 01:31:55'),(21,NULL,NULL,'{\"mood\":\"relaxation\"}','[14,11,14]','2025-05-08 11:20:08'),(22,NULL,NULL,'{\"mood\":\"energy\"}','[2,10,12]','2025-05-08 11:20:10'),(23,NULL,NULL,'{\"mood\":\"focus\"}','[13,3,13]','2025-05-08 11:20:12'),(24,NULL,NULL,'{\"mood\":\"balance\"}','[15,9,4]','2025-05-08 11:20:14');
/*!40000 ALTER TABLE `quiz_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `status` enum('active','inactive','locked') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active' COMMENT 'User account status (active, inactive, locked)',
  `newsletter_subscribed` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Flag indicating newsletter subscription (0=No, 1=Yes)',
  `reset_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Secure token for password reset requests',
  `reset_token_expires_at` datetime DEFAULT NULL COMMENT 'Expiry timestamp for the password reset token',
  `address_line1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Primary address line',
  `address_line2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Secondary address line (optional)',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'City name',
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'State / Province / Region',
  `postal_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Postal or ZIP code',
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Country name or code',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the last record update',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_reset_token` (`reset_token`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin User','admin@thescent.com','y02IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin','active',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-04-13 16:26:25','2025-04-28 11:36:41'),(6,'Abc Def','abc@def.com','$2y$10$PcdT7JAlQu1IeEOWkwz6C.xh7eAHAqPm4nsF/imqR7iO/eyhDr3Uq','user','active',0,NULL,NULL,'123 George Street','#10-08','Melborne','California','12345','US','2025-04-28 01:35:09','2025-05-06 01:48:11'),(7,'Scent Admin','webadmin@scent.com','$2y$10$8cFKhcMHlrMw7gVy45PYFeh4EPDV.1wFRmNtxfcBIkOhNFngbifzC','admin','active',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-04-28 01:35:09','2025-04-28 11:36:41'),(9,'Asd Zxc','asd@zxc.com','$2y$10$rA6MYJWhUS3xutzH0v1lju/BRVWDvlBVwFyf2PmQ8/ZlB6p9iWm9u','user','active',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-05-06 01:52:58','2025-05-06 01:52:58'),(10,'Qaz Wsx','qaz@wsx.com','$2y$10$kZifDi5UqTJ7.sLK689rxuFxkctsO2rlo2Vdawhjnh.FReIge1O6q','user','active',1,NULL,NULL,'32423 fgferty hgfh','trt 546','fghfgh','fghjfgh','34231','AU','2025-05-06 08:32:03','2025-05-06 08:32:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'the_scent'
--

--
-- Dumping routines for database 'the_scent'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-09 12:17:56
